"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const supertest_1 = __importDefault(require("supertest"));
const app_1 = __importDefault(require("../app"));
const connection_1 = __importDefault(require(".././db/postgres/connection"));
const test_data_json_1 = require("../db/postgres/data/test-data.json");
const seed_1 = require("../db/postgres/seed/seed");
afterAll(() => {
    connection_1.default.end();
});
beforeEach(() => {
    return (0, seed_1.seed)(test_data_json_1.users, test_data_json_1.music, test_data_json_1.reviews);
});
describe("/api/music", () => {
    describe("GET /api/music", () => {
        test("200: should return an array of object with all music", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music")
                .expect(200)
                .then(({ body }) => {
                body.music.forEach((music) => {
                    expect(music).toHaveProperty("music_id");
                    expect(music).toHaveProperty("artist_ids");
                    expect(music).toHaveProperty("artist_names");
                    expect(music).toHaveProperty("name");
                    expect(music).toHaveProperty("type");
                    expect(music).toHaveProperty("tracks");
                    expect(music).toHaveProperty("album_id");
                    expect(music).toHaveProperty("genres");
                    expect(music).toHaveProperty("preview");
                    expect(music).toHaveProperty("album_img");
                    expect(music).toHaveProperty("release_date");
                    expect(typeof music.artist_names).toBe("object");
                    expect(typeof music.tracks).toBe("object");
                });
            });
        });
        test("404: incorrect path", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/musicincorrect")
                .expect(404)
                .then((Response) => {
                expect(Response.body.msg).toBe("incorrect path - path not found");
            });
        });
    });
    describe("GET /api/music?music_id", () => {
        test("200: should return a single object of music by music_id", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music?music_id=1MVqeIAwhD4T44AKVkIfic")
                .expect(200)
                .then(({ body }) => {
                expect(body.music.music_id).toBe("1MVqeIAwhD4T44AKVkIfic");
            });
        });
        test("404: not found", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music?music_id=wrongthing")
                .expect(404)
                .then((Response) => {
                expect(Response.body.msg).toBe("not found");
            });
        });
    });
    describe("GET /api/music?artist_ids", () => {
        test("200: should return an array of music object by artist_ids for a particular artist", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music?artist_ids=4oLeXFyACqeem2VImYeBFe")
                .expect(200)
                .then(({ body }) => {
                expect(body.music[0].artist_ids).toContain("4oLeXFyACqeem2VImYeBFe");
            });
        });
    });
    describe("GET /api/music?genres", () => {
        test("200: should return an array of music with the same genre", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music?genres=country")
                .expect(200)
                .then(({ body }) => {
                expect(body.music[0].genres).toEqual(["Country"]);
            });
        });
    });
    describe("GET /api/music?order", () => {
        test("200: should return an array of music ASC or DESC by release_date if no other query, DESC by default", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music?order=ASC")
                .expect(200)
                .then(({ body }) => {
                expect(parseInt(body.music[0].release_date)).toBeLessThan(parseInt(body.music[1].release_date));
            });
        });
    });
    describe("GET /api/music?pagination", () => {
        test("200: should return an array of music paginated beyond the default limit of 40", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music?p=2")
                .expect(200)
                .then(({ body }) => {
                expect(body.music.length).toBe(10);
            });
        });
    });
    describe("GET /api/music?avg_rating", () => {
        it("200: should return an array of music with avg_rating property when passed true", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music?avg_rating=true")
                .expect(200)
                .then(({ body }) => {
                body.music.forEach((song) => {
                    expect(song).toHaveProperty("avg_rating");
                });
            });
        });
        it("200: should default to false", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music")
                .expect(200)
                .then(({ body }) => {
                body.music.forEach((song) => {
                    expect(song).not.toHaveProperty("avg_rating");
                });
            });
        });
        it("200: should chain with other queries", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/music?music_id=1MVqeIAwhD4T44AKVkIfic&avg_rating=true")
                .expect(200)
                .then(({ body }) => {
                expect(body.music).toHaveProperty("avg_rating");
            });
        });
    });
    describe("POST /api/music", () => {
        it("201: should create a new music item in the database", async () => {
            const { body } = await (0, supertest_1.default)(app_1.default)
                .post("/api/music")
                .send({
                music_id: "test-music-id",
                artist_ids: ["test-artist-id"],
                artist_names: ["test-artist-names"],
                name: "test-name",
                type: "song",
                tracks: ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"],
                release_date: "2023-08-05",
            })
                .expect(201);
            const newMusic = await (0, supertest_1.default)(app_1.default)
                .get(`/api/music?music_id=test-music-id`)
                .expect(200);
            expect(newMusic.body.music.music_id).toBe("test-music-id");
        });
    });
});
describe("/api/reviews", () => {
    describe("GET /api/reviews", () => {
        it("200: should return an array of review objects", () => {
            return (0, supertest_1.default)(app_1.default)
                .get("/api/reviews")
                .expect(200)
                .then((response) => {
                const { body } = response;
                body.reviews.forEach((review) => {
                    expect(review).toMatchObject({
                        music_id: expect.any(String),
                        username: expect.any(String),
                        rating: expect.any(Number),
                        review_id: expect.any(Number),
                        review_title: expect.any(String || null),
                        review_body: expect.any(String || null),
                        created_at: expect.any(String),
                    });
                });
            });
        });
    });
    describe("/api/reviews/:music_id", () => {
        describe("GET /api/reviews/:music_id", () => {
            it("200: should return an array of review objects with passed music_id", () => {
                return (0, supertest_1.default)(app_1.default)
                    .get("/api/reviews/2IGMVunIBsBLtEQyoI1Mu7")
                    .expect(200)
                    .then((response) => {
                    const { body } = response;
                    body.reviews.forEach((review) => {
                        expect(review).toMatchObject({
                            review_id: expect.any(Number),
                            music_id: "2IGMVunIBsBLtEQyoI1Mu7",
                            username: expect.any(String),
                            rating: expect.any(Number),
                            review_title: expect.any(String || null),
                            review_body: expect.any(String || null),
                            created_at: expect.any(String),
                        });
                    });
                });
            });
        });
        describe("POST /api/reviews/:music_id", () => {
            test("201: inserts a new review to the db and returns the new review back to the client", () => {
                const newReview = {
                    username: "night_owl_philosopher",
                    rating: 1,
                    review_title: "Not what I was expecting",
                    review_body: "I was expecting the song to be all about escaping being tied up underwater, what a disappointment!",
                };
                return (0, supertest_1.default)(app_1.default)
                    .post("/api/reviews/4OMJGnvZfDvsePyCwRGO7X")
                    .send(newReview)
                    .expect(201)
                    .then(({ body: { review } }) => {
                    expect(review.review_id).toEqual(expect.any(Number));
                    expect(review.review_title).toBe("Not what I was expecting");
                    expect(review.review_body).toBe("I was expecting the song to be all about escaping being tied up underwater, what a disappointment!");
                    expect(review.music_id).toBe("4OMJGnvZfDvsePyCwRGO7X");
                    expect(review.username).toBe("night_owl_philosopher");
                    expect(review.rating).toBe(1);
                    expect(review.created_at).toEqual(expect.any(String));
                })
                    .then(() => {
                    return (0, supertest_1.default)(app_1.default)
                        .get("/api/reviews/4OMJGnvZfDvsePyCwRGO7X")
                        .expect(200);
                })
                    .then(({ body: { reviews } }) => {
                    expect(reviews.some((review) => review.review_body ===
                        "I was expecting the song to be all about escaping being tied up underwater, what a disappointment!")).toBe(true);
                });
            });
            test("201: inserts a new review to the db and returns the new review back to the client, with optional fields omitted", () => {
                const ratingOnlyReview = {
                    username: "night_owl_philosopher",
                    rating: 3,
                };
                return (0, supertest_1.default)(app_1.default)
                    .post("/api/reviews/2IGMVunIBsBLtEQyoI1Mu7")
                    .send(ratingOnlyReview)
                    .expect(201)
                    .then(({ body: { review } }) => {
                    expect(review.review_id).toEqual(expect.any(Number));
                    expect(review.review_title).toBe(null);
                    expect(review.review_body).toBe(null);
                    expect(review.music_id).toBe("2IGMVunIBsBLtEQyoI1Mu7");
                    expect(review.username).toBe("night_owl_philosopher");
                    expect(review.rating).toBe(3);
                    expect(review.created_at).toEqual(expect.any(String));
                });
            });
            test("POST:400 responds with an appropriate status and error message when provided with a bad review (missing required keys)", () => {
                const badReview = {
                    username: "night_owl_philosopher",
                    review_title: "I hate rating things, it seems petty",
                };
                return (0, supertest_1.default)(app_1.default)
                    .post("/api/reviews/4OMJGnvZfDvsePyCwRGO7X")
                    .send(badReview)
                    .expect(400)
                    .then(({ body: { msg } }) => {
                    expect(msg).toBe("bad request");
                });
            });
            test("POST:404 responds with an appropriate status and error message when provided with an incorrect screen name)", () => {
                const incorrectScreenNameReview = {
                    username: "rumpelstiltskin",
                    rating: 1,
                    review_body: "I bet my name wasn't in your database",
                };
                return (0, supertest_1.default)(app_1.default)
                    .post("/api/reviews/4OMJGnvZfDvsePyCwRGO7X")
                    .send(incorrectScreenNameReview)
                    .expect(404)
                    .then(({ body: { msg } }) => {
                    expect(msg).toBe("not found");
                });
            });
            test("POST:404 sends an appropriate status and error message when given a valid but non-existent music id", () => {
                const reviewOfNonExistentSong = {
                    username: "night_owl_philosopher",
                    rating: 10,
                    review_title: "Truly Wonderful",
                    review_body: "I love to discuss the non-existent - the impossible! I'm the existentialism equivalent of Groucho Marx...",
                };
                return (0, supertest_1.default)(app_1.default)
                    .post("/api/reviews/4OMJGnvPxDvsePyCwRGO0X")
                    .send(reviewOfNonExistentSong)
                    .expect(404)
                    .then(({ body: { msg } }) => {
                    expect(msg).toBe("not found");
                });
            });
        });
    });
    describe("/api/reviews/:review_id", () => {
        it("204: should delete review from database", async () => {
            await (0, supertest_1.default)(app_1.default).delete("/api/reviews/1").expect(204);
            return (0, supertest_1.default)(app_1.default)
                .get("/api/reviews")
                .expect(200)
                .then((response) => {
                const { body } = response;
                body.reviews.every((review) => {
                    review.review_id !== 1;
                });
            });
        });
    });
    test("404 responds with an appropriate status and error message when given a non-existent id", () => {
        return (0, supertest_1.default)(app_1.default)
            .delete("/api/reviews/999")
            .expect(404)
            .then(({ body: { msg } }) => {
            expect(msg).toBe("not found");
        });
    });
    test("400 responds with an appropriate status and error message when given an invalid id", () => {
        return (0, supertest_1.default)(app_1.default)
            .delete("/api/reviews/no-review")
            .expect(400)
            .then(({ body: { msg } }) => {
            expect(msg).toBe("bad request");
        });
    });
});
// describe("/api/search", () => {
//   describe("track", () => {
//     it("200: should be able to return a track from spotify, that doesn`t exist in database", () => {
//       return request(app)
//         .get("/api/search?q=take+care&type=track")
//         .expect(200)
//         .then(({ body }) => {
//           expect(
//             body.music.some((music: Music) =>
//               /((take).*(care))|((care).*(take))/gi.test(music.name)
//             )
//           ).toBe(true);
//         });
//     });
//   });
//   describe("album", () => {
//     it("200: should be able to return a album from spotify, that doesn`t exist in database", () => {
//       return request(app)
//         .get("/api/search?q=take+care&type=album")
//         .expect(200)
//         .then(({ body }) => {
//           expect(
//             body.music.some((music: Music) =>
//               /((take).*(care))|((care).*(take))/gi.test(music.name)
//             )
//           ).toBe(true);
//         });
//     });
//   });
//   describe("update database", () => {
//     it("200: should update the database to include results from spotify", async () => {
//       const spotifyResponse = await request(app)
//         .get("/api/search?q=bohemian+rhapsody&type=track")
//         .expect(200);
//       const firstHit = spotifyResponse.body.music[0].music_id;
//       const databaseResponse = await request(app)
//         .get(`/api/music?music_id=${firstHit}`)
//         .expect(200);
//       const databaseTrack = databaseResponse.body.music;
//       expect(databaseTrack.music_id).toBe(firstHit);
//     });
//   });
// });
it.only("should ", async () => {
    const req = [
        {
            album_id: "51HFfu3GhuXa4VUnlpJJy8",
            album_img: "https://i.scdn.co/image/ab67616d0000b27399e60c06162fd5cb1ff6d0b8",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nala Sinephro"],
            genres: null,
            music_id: "5xYR2G6YOEzX2X9asFUrOE",
            name: "Space 1",
            preview: "https://p.scdn.co/mp3-preview/d9a3701c752a3f6bc77704b228f2331ce7735d44?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-09-03",
            tracks: null,
            type: "track",
        },
        {
            album_id: "51HFfu3GhuXa4VUnlpJJy8",
            album_img: "https://i.scdn.co/image/ab67616d0000b27399e60c06162fd5cb1ff6d0b8",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nala Sinephro"],
            genres: null,
            music_id: "3I6J7zLXCGDwqm0PaNKqWI",
            name: "Space 2",
            preview: "https://p.scdn.co/mp3-preview/d266e77c467f237457755c35ef2963829d3d45b0?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-09-03",
            tracks: null,
            type: "track",
        },
        {
            album_id: "51HFfu3GhuXa4VUnlpJJy8",
            album_img: "https://i.scdn.co/image/ab67616d0000b27399e60c06162fd5cb1ff6d0b8",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nala Sinephro"],
            genres: null,
            music_id: "11lcWjr6YXEH0EOCcU7Pfp",
            name: "Space 4",
            preview: "https://p.scdn.co/mp3-preview/7b77bc4e7c45812d4f1b528f521d01c68c81c267?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-09-03",
            tracks: null,
            type: "track",
        },
        {
            album_id: "51HFfu3GhuXa4VUnlpJJy8",
            album_img: "https://i.scdn.co/image/ab67616d0000b27399e60c06162fd5cb1ff6d0b8",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nala Sinephro"],
            genres: null,
            music_id: "6kpoN7Z1mahkMePKztQdHt",
            name: "Space 8",
            preview: "https://p.scdn.co/mp3-preview/5db222e0daa3a1861085841d9d47947ad2671b4a?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-09-03",
            tracks: null,
            type: "track",
        },
        {
            album_id: "51HFfu3GhuXa4VUnlpJJy8",
            album_img: "https://i.scdn.co/image/ab67616d0000b27399e60c06162fd5cb1ff6d0b8",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nala Sinephro"],
            genres: null,
            music_id: "0SMKIx5AuEskIFMzZgZNIV",
            name: "Space 7",
            preview: "https://p.scdn.co/mp3-preview/b3895b2006897ab6db80385e55f313ddb44411af?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-09-03",
            tracks: null,
            type: "track",
        },
        {
            album_id: "51HFfu3GhuXa4VUnlpJJy8",
            album_img: "https://i.scdn.co/image/ab67616d0000b27399e60c06162fd5cb1ff6d0b8",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nala Sinephro"],
            genres: null,
            music_id: "4TS1SMLEEhjKr6qeKjfq5z",
            name: "Space 3",
            preview: "https://p.scdn.co/mp3-preview/3f5448e73341cd4599aa7e0a2edfea4c76876dc6?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-09-03",
            tracks: null,
            type: "track",
        },
        {
            album_id: "4X0zpgV5SkAiOsTinSy0Tq",
            album_img: "https://i.scdn.co/image/ab67616d0000b2734ebfdcc203d8987f5d56077f",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO", "6QMuw5LnvFnETkB5gwc9JC"],
            artist_names: ["Nala Sinephro", "Lyle Barton"],
            genres: null,
            music_id: "7glonKcaKhAmoK5MiewROa",
            name: "Ada",
            preview: "https://p.scdn.co/mp3-preview/e9b0d0a239469aedc75dfde7759a669ef4844159?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2022-07-01",
            tracks: null,
            type: "track",
        },
        {
            album_id: "51HFfu3GhuXa4VUnlpJJy8",
            album_img: "https://i.scdn.co/image/ab67616d0000b27399e60c06162fd5cb1ff6d0b8",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nala Sinephro"],
            genres: null,
            music_id: "5qQiAyGH1zJtCwPDRvs1wa",
            name: "Space 5",
            preview: "https://p.scdn.co/mp3-preview/c159060392b07be4c7464159c99e587b63eb1aaa?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-09-03",
            tracks: null,
            type: "track",
        },
        {
            album_id: "51HFfu3GhuXa4VUnlpJJy8",
            album_img: "https://i.scdn.co/image/ab67616d0000b27399e60c06162fd5cb1ff6d0b8",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nala Sinephro"],
            genres: null,
            music_id: "0jqUHZusqIo9xwre4ZGLdh",
            name: "Space 6",
            preview: "https://p.scdn.co/mp3-preview/f75434265771fa2a519c2cba11cdc807a2fc5bb0?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-09-03",
            tracks: null,
            type: "track",
        },
        {
            album_id: "6rxTayBNingFbjnFEfdEPD",
            album_img: "https://i.scdn.co/image/ab67616d0000b2734fa68ab3ab3c4645e34728a5",
            artist_ids: ["2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nala Sinephro"],
            genres: null,
            music_id: "4thtPg86ELKBMbqmaXKWQO",
            name: "Space 3",
            preview: "https://p.scdn.co/mp3-preview/3f5448e73341cd4599aa7e0a2edfea4c76876dc6?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-08-17",
            tracks: null,
            type: "track",
        },
        {
            album_id: "7p1KmTe3TtMb7ojCYNmvpc",
            album_img: "https://i.scdn.co/image/ab67616d0000b273344b04b0877894a136bd1a47",
            artist_ids: ["6O5k8LLRfDK8v9jj1GazAQ", "2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nubya Garcia", "Nala Sinephro"],
            genres: null,
            music_id: "4Wt7ZGzelNDUZCCZxgLsuK",
            name: "Together Is A Beautiful Place To Be - Nala Sinephro Remix",
            preview: null,
            release_date: "2021-10-22",
            tracks: null,
            type: "track",
        },
        {
            album_id: "3aJmqrLaIO2NdvhLFSFP8L",
            album_img: "https://i.scdn.co/image/ab67616d0000b273090788ddb71a11fdecab8cec",
            artist_ids: ["0TArUQakaqRxFMynA8vA7q", "2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Robert Ames", "Nala Sinephro"],
            genres: null,
            music_id: "1a2ebexA5N9RgCJ8LQOGCT",
            name: "Tympanum (feat. Nala Sinephro)",
            preview: "https://p.scdn.co/mp3-preview/4ae506db7a52b0d9ba1c9d0091e07630cd80d632?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2021-05-28",
            tracks: null,
            type: "track",
        },
        {
            album_id: "4x9VGbC18b9s9f5rxxngIr",
            album_img: "https://i.scdn.co/image/ab67616d0000b2737300fef4958e03084cf2df83",
            artist_ids: ["6O5k8LLRfDK8v9jj1GazAQ", "2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nubya Garcia", "Nala Sinephro"],
            genres: null,
            music_id: "4z17HamuFu3h0yiZ59xRzY",
            name: "Together Is A Beautiful Place To Be - Nala Sinephro Remix",
            preview: null,
            release_date: "2021-10-07",
            tracks: null,
            type: "track",
        },
        {
            album_id: "6KiUxpyXAjG3cNadTFVEem",
            album_img: "https://i.scdn.co/image/ab67616d0000b27314d7958df307cffdd7d26c90",
            artist_ids: ["6O5k8LLRfDK8v9jj1GazAQ", "2h5syT5XdsQgKLq8Yn1klO"],
            artist_names: ["Nubya Garcia", "Nala Sinephro"],
            genres: null,
            music_id: "73PlAThrIrVXayCpjHYV3N",
            name: "Together Is A Beautiful Place To Be - Nala Sinephro Remix",
            preview: null,
            release_date: "2023-06-27",
            tracks: null,
            type: "track",
        },
        {
            album_id: "67zFApoGwQ250TbCqGg3aQ",
            album_img: "https://i.scdn.co/image/ab67616d0000b273a6749d62b2f3c5bf7ce8d0a4",
            artist_ids: ["7occ8YAUAF3XJbC3uCq1iL"],
            artist_names: ["Hana Shafa"],
            genres: null,
            music_id: "1kQzWYUZnqQJm3H43eDNXd",
            name: "Mal Onchilla",
            preview: "https://p.scdn.co/mp3-preview/61091bc53e02f09d09d78b197dc95ee86adb774a?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2022-11-04",
            tracks: null,
            type: "track",
        },
        {
            album_id: "6GuOuQEgcOAyfNHCDtSRAk",
            album_img: "https://i.scdn.co/image/ab67616d0000b273eadd20455abacc4be7a82b46",
            artist_ids: ["0uOTP7pznZgZc06fuftoJ4"],
            artist_names: ["NALALA"],
            genres: null,
            music_id: "2uGrSoj2G2ttrcGvDSl5Bg",
            name: "&ME",
            preview: "https://p.scdn.co/mp3-preview/557169b8845871808d9c0151c6cd590b6dcd1005?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2023-12-18",
            tracks: null,
            type: "track",
        },
        {
            album_id: "4FC9o6NMKwgC2rJlulDvwf",
            album_img: "https://i.scdn.co/image/ab67616d0000b273b1c9dd7dc168394df4571ee2",
            artist_ids: ["0pK1kMsD0cnIoFPL675cAa", "7kLMjxzItr4NbjZx1I4jqd"],
            artist_names: ["Don Valiyavelicham", "Sreya Anna Joseph"],
            genres: null,
            music_id: "4v0sj4FiU05ZWkPmgDXUI6",
            name: "Nalla Devane",
            preview: "https://p.scdn.co/mp3-preview/2aa72a55aed33237aa4cea1f1907e7c6e41120ea?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2007-05-02",
            tracks: null,
            type: "track",
        },
        {
            album_id: "0zAb3uPNkk0JGsyKaiflgz",
            album_img: "https://i.scdn.co/image/ab67616d0000b27350abdbb1059bc2a06da2ee81",
            artist_ids: ["12l1SqSNsg2mI2IcXpPWjR", "2IUtwMti1OiT3lkW6RubgH"],
            artist_names: ["M. M. Keeravani", "K. S. Chithra"],
            genres: null,
            music_id: "4nbHh7JqUTUMsDgbCmmafX",
            name: "Nalla Nallaani Kalla",
            preview: "https://p.scdn.co/mp3-preview/44b4cc2e5088912ac00f3f79ba9a5d57b3e08e96?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2004",
            tracks: null,
            type: "track",
        },
        {
            album_id: "5maY5nikux4eBxcRCThzrA",
            album_img: "https://i.scdn.co/image/ab67616d0000b27300402fb671431882e0375da4",
            artist_ids: ["2kLa7JZu4Ijdz1Gle2khZh"],
            artist_names: ["TSHA"],
            genres: null,
            music_id: "43EY9ICUxH5kFllYxEEFus",
            name: "Nala (Outro)",
            preview: "https://p.scdn.co/mp3-preview/6d25f19093294d5c8141ccb3e28167585fd80e8a?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2022",
            tracks: null,
            type: "track",
        },
        {
            album_id: "45CJ4LhQDf4eHyfyrFvo29",
            album_img: "https://i.scdn.co/image/ab67616d0000b27339ba3c39545113f29ca082ac",
            artist_ids: ["4SCWiQbJCMTHK737aNUqBJ"],
            artist_names: ["Little Symphony"],
            genres: null,
            music_id: "4gupGpxbSteeJPjJgDtHL5",
            name: "Nala",
            preview: "https://p.scdn.co/mp3-preview/4dc8cb3d2f81ef7c3205b617d870505e60927a7c?cid=114fce6830b84eb5868f3795b0847609",
            release_date: "2020-08-28",
            tracks: null,
            type: "track",
        },
    ];
    console.log(req.length);
    const res = await (0, supertest_1.default)(app_1.default)
        .post("/api/search")
        .send({ matchedMusic: req })
        .expect(200);
    console.log("🚀 ~ it.only ~ res:", res.body.music.length);
    const res2 = await (0, supertest_1.default)(app_1.default)
        .post("/api/search")
        .send({ matchedMusic: req })
        .expect(200);
    // console.log(res.body);
    // console.log("🚀 ~ it.only ~ res2:", res2.body);
});
