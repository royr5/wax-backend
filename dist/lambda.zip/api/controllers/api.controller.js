"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = (_req, res, _next) => {
    res.status(200).send({ msg: "ok" });
};
